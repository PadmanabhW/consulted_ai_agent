from flask import Flask, jsonify, request
from flask_cors import CORS
import requests
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
CORS(app)

API_KEY = os.getenv("SAM_API_KEY")

def fetch_rfps(keywords):
    url = "https://open.gsa.gov/api/get-opportunities-public-api/"
    params = {
        "api_key": API_KEY,
        "noticeType": "Presolicitation",
        "keyword": " ".join(keywords),
        "sort": "-publicationDate",
        "limit": 20
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        results = []
        for item in data.get("opportunitiesData", []):
            results.append({
                "title": item.get("title"),
                "agency": item.get("agency", {}).get("name"),
                "date": item.get("publicationDate"),
                "link": f"https://sam.gov/opp/{item.get('id')}/view"
            })
        return results
    return []

@app.route("/api/rfps", methods=["GET"])
def get_rfps():
    keywords = request.args.get("keywords", "cloud DevOps AI software data").split(",")
    rfps = fetch_rfps(keywords)
    return jsonify(rfps)

if __name__ == "__main__":
    app.run(debug=True)